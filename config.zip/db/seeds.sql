USE finesse_db;

INSERT INTO goals (goal_name, removed, createDate) VALUES ("Lose Weight", true, "2019-01-23");

INSERT INTO goals (goal_name, removed, createDate) VALUES ("Gain Weight", false, "2019-01-23");

INSERT INTO goals (goal_name, removed, createDate) VALUES ("Learn A New Skill", true, "2019-01-23");

